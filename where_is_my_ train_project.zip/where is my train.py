from tkinter import*
from tkcalendar import Calendar
import datetime as dt
from tkinter import messagebox
import time
win=Tk()
win.title('Where is my train')
win.maxsize(height='800',width='1550')
win.minsize(height='800',width='1550')
def findtrain():
    E1=e1.get()
    E2=e2.get()
    E3=se1.get()
    pj=['PRAYAGRAJ JUCTION','prayagraj juction','Praygraj Juction','prayagaraj','PRAYAGRAJ','p']
    nd=['NEW DELHI','new delhi','New Delhi','DELHI','delhi','d']
    search=['12309','12417','12561','12505']
    if((E1 in pj and E2 in nd) or E3 in search):
              if((E1 in pj and E2 in nd)or E3 in search):
                   def pjnd():
                       window=Toplevel()
                       window.title('Praygraj to New Delhi Update')
                       window.maxsize(height="700",width="360")
                       window.minsize(height="700",width="360")
                       f2=Frame(window,height="690",width="360",bg="red")
                       f2.place(x=0,y=0)
                       img5=Label(f2,image=img4)
                       img5.pack()
                       def refresh():
                           '''lb2=Label(window,text="12:14 AM",bg='white',fg='red',font=('sans serif',12))
                           lb2.place(x=280,y=60)
                           ####################label3##########################
                           lb3=Label(window,text="12:12 AM",bg='white',fg='green',font=('sans serif',12))
                           lb3.place(x=9,y=60)
                           img5=Label(f2,image=img4)
                           img5.pack()'''
                           if (hourse<=12 and (minute>=0 and am == 'AM')): 
                               z=30
                               while(z<=30):
                                   f4=Frame(window,height="39",width="30")
                                   f4.place(x=88,y=z)
                                   img7=Label(f4,image=img6,bg='skyblue',width="26")
                                   img7.place(x=0,y=0)
                                   z=z+10                              
                               if(hourse==12 and (minute<=29 and am == 'AM')):
                                   z=30
                                   while(z<80):
                                       f4=Frame(window,height="40",width="35")
                                       f4.place(x=84,y=z)
                                       img7=Label(f4,image=img6,bg='skyblue')
                                       img7.place(x=0,y=0)
                                       z=z+10 
                               elif(hourse==12 and (minute<=59 and am=='AM')):
                                   z=30
                                   while(z<130):
                                       f4=Frame(window,height="40",width="35")
                                       f4.place(x=84,y=z)
                                       img7=Label(f4,image=img6,bg='skyblue')
                                       img7.place(x=0,y=0)
                                       z=z+10
                               elif(hourse==1 and (minute<=29 and am=='AM')):
                                   z=30
                                   while(z<180):
                                       f4=Frame(window,height="40",width="35")
                                       f4.place(x=84,y=z)
                                       img7=Label(f4,image=img6,bg='skyblue')
                                       img7.place(x=0,y=0)
                                       z=z+10
                               elif(hourse==1 and (minute<=59 and am=='AM')):
                                   z=30
                                   while(z<230):
                                       f4=Frame(window,height="40",width="35")
                                       f4.place(x=84,y=z)
                                       img7=Label(f4,image=img6,bg='skyblue')
                                       img7.place(x=0,y=0)
                                       z=z+10
                               elif(hourse==2 and (minute<=22 and am=='AM')):
                                   z=30
                                   while(z<270):
                                       f4=Frame(window,height="40",width="35")
                                       f4.place(x=84,y=z)
                                       img7=Label(f4,image=img6,bg='skyblue')
                                       img7.place(x=0,y=0)
                                       z=z+10             
                               elif(hourse==2 and (minute<=39 and am=='AM')):
                                    z=30
                                    while(z<300):
                                       f4=Frame(window,height="40",width="35")
                                       f4.place(x=84,y=z)
                                       img7=Label(f4,image=img6,bg='skyblue')
                                       img7.place(x=0,y=0)
                                       z=z+10
                                       ###################label1############################
                                       l1=Label(window,text="2:22 AM",bg='white',fg='red',font=('sans serif',12))
                                       l1.place(x=291,y=330)
                                       ####################label4##########################
                                       lb4=Label(window,text="2:15 AM",bg="white",fg="green",font=('sans serif',12))
                                       lb4.place(x=9,y=330)
                               elif(hourse==2 and (minute<=59 and am=='AM')):
                                    z=30
                                    while(z<330):
                                       f4=Frame(window,height="40",width="35")
                                       f4.place(x=84,y=z)
                                       img7=Label(f4,image=img6,bg='skyblue')
                                       img7.place(x=0,y=0)
                                       z=z+10
                                       ###################label1############################
                                       l1=Label(window,text="2:22 AM",bg='white',fg='red',font=('sans serif',12))
                                       l1.place(x=291,y=330)
                                       ####################label4##########################
                                       lb4=Label(window,text="2:15 AM",bg="white",fg="green",font=('sans serif',12))
                                       lb4.place(x=9,y=330)
                               elif(hourse==3 and (minute<=59 and am=='AM')):
                                    z=30
                                    while(z<360):
                                       f4=Frame(window,height="40",width="35")
                                       f4.place(x=84,y=z)
                                       img7=Label(f4,image=img6,bg='skyblue')
                                       img7.place(x=0,y=0)
                                       z=z+10
                                       ###################label1############################
                                       l1=Label(window,text="2:22 AM",bg='white',fg='red',font=('sans serif',12))
                                       l1.place(x=291,y=330)
                                       ####################label4##########################
                                       lb4=Label(window,text="2:15 AM",bg="white",fg="green",font=('sans serif',12))
                                       lb4.place(x=9,y=330)
                               elif(hourse==4 and (minute<=29 and am=='AM')):
                                    z=30
                                    while(z<390):
                                       f4=Frame(window,height="40",width="35")
                                       f4.place(x=84,y=z)
                                       img7=Label(f4,image=img6,bg='skyblue')
                                       img7.place(x=0,y=0)
                                       z=z+10
                                       ###################label1############################
                                       l1=Label(window,text="2:22 AM",bg='white',fg='red',font=('sans serif',12))
                                       l1.place(x=291,y=330)
                                       ####################label4##########################
                                       lb4=Label(window,text="2:15 AM",bg="white",fg="green",font=('sans serif',12))
                                       lb4.place(x=9,y=330)
                               elif(hourse==4 and (minute<=59 and am=='AM')):
                                    z=30
                                    while(z<420):
                                       f4=Frame(window,height="40",width="35")
                                       f4.place(x=84,y=z)
                                       img7=Label(f4,image=img6,bg='skyblue')
                                       img7.place(x=0,y=0)
                                       z=z+10
                                       ###################label1############################
                                       l1=Label(window,text="2:22 AM",bg='white',fg='red',font=('sans serif',12))
                                       l1.place(x=291,y=330)
                                       ####################label4##########################
                                       lb4=Label(window,text="2:15 AM",bg="white",fg="green",font=('sans serif',12))
                                       lb4.place(x=9,y=330)
                               elif(hourse==5 and (minute<=29 and am=='AM')):
                                    z=30
                                    while(z<450):
                                       f4=Frame(window,height="40",width="35")
                                       f4.place(x=84,y=z)
                                       img7=Label(f4,image=img6,bg='skyblue')
                                       img7.place(x=0,y=0)
                                       z=z+10
                                       ###################label1############################
                                       l1=Label(window,text="2:22 AM",bg='white',fg='red',font=('sans serif',12))
                                       l1.place(x=291,y=330)
                                       ####################label4##########################
                                       lb4=Label(window,text="2:15 AM",bg="white",fg="green",font=('sans serif',12))
                                       lb4.place(x=9,y=330)
                               elif(hourse==5 and (minute<=59 and am=='AM')):
                                    z=30
                                    while(z<480):
                                       f4=Frame(window,height="40",width="35")
                                       f4.place(x=84,y=z)
                                       img7=Label(f4,image=img6,bg='skyblue')
                                       img7.place(x=0,y=0)
                                       z=z+10
                                       ###################label1############################
                                       l1=Label(window,text="2:22 AM",bg='white',fg='red',font=('sans serif',12))
                                       l1.place(x=291,y=330)
                                       ####################label4##########################
                                       lb4=Label(window,text="2:15 AM",bg="white",fg="green",font=('sans serif',12))
                                       lb4.place(x=9,y=330)
                               elif(hourse==6 and (minute<=29 and am=='AM')):
                                    z=30
                                    while(z<510):
                                       f4=Frame(window,height="40",width="35")
                                       f4.place(x=84,y=z)
                                       img7=Label(f4,image=img6,bg='skyblue')
                                       img7.place(x=0,y=0)
                                       z=z+10
                                       ###################label1############################
                                       l1=Label(window,text="2:22 AM",bg='white',fg='red',font=('sans serif',12))
                                       l1.place(x=291,y=330)
                                       ####################label4##########################
                                       lb4=Label(window,text="2:15 AM",bg="white",fg="green",font=('sans serif',12))
                                       lb4.place(x=9,y=330)
                               elif(hourse==6 and (minute<=59 and am=='AM')):
                                    z=30
                                    while(z<540):
                                       f4=Frame(window,height="40",width="35")
                                       f4.place(x=84,y=z)
                                       img7=Label(f4,image=img6,bg='skyblue')
                                       img7.place(x=0,y=0)
                                       z=z+10
                                       ###################label1############################
                                       l1=Label(window,text="2:22 AM",bg='white',fg='red',font=('sans serif',12))
                                       l1.place(x=291,y=330)
                                       ####################label4##########################
                                       lb4=Label(window,text="2:15 AM",bg="white",fg="green",font=('sans serif',12))
                                       lb4.place(x=9,y=330)
                               elif(hourse==7 and (minute<=40 and am=='AM')):
                                    z=30
                                    while(z<570):
                                       f4=Frame(window,height="40",width="35")
                                       f4.place(x=84,y=z)
                                       img7=Label(f4,image=img6,bg='skyblue')
                                       img7.place(x=0,y=0)
                                       z=z+10
                                       ###################label1############################
                                       l1=Label(window,text="2:22 AM",bg='white',fg='red',font=('sans serif',12))
                                       l1.place(x=291,y=330)
                                       ####################label4##########################
                                       lb4=Label(window,text="2:15 AM",bg="white",fg="green",font=('sans serif',12))
                                       lb4.place(x=9,y=330)                                      
                               elif(hourse>=7 and (minute>=0 and am=='AM')):
                                   z=30
                                   while(z<620):
                                       f4=Frame(window,height="39",width="30")
                                       f4.place(x=91,y=z)
                                       img7=Label(f4,image=img6,bg='skyblue',width="26")
                                       img7.place(x=0,y=0)
                                       z=z+10
                                       ###################label1############################
                                       l1=Label(window,text="2:22 AM",bg='white',fg='red',font=('sans serif',12))
                                       l1.place(x=291,y=330)
                                       ####################label4##########################
                                       lb4=Label(window,text="2:15 AM",bg="white",fg="green",font=('sans serif',12))
                                       lb4.place(x=9,y=330)                                     
                                       lb2=Label(window,text="--",bg='white',font=('sans serif',20))
                                       lb2.place(x=320,y=640)
                                       ####################label3##########################
                                       lb3=Label(window,text="7:40 AM",bg='white',fg='green',font=('sans serif',12))
                                       lb3.place(x=9,y=640)
                               else:
                                   print('not time')
                                ##################label2#############################
                               lb2=Label(window,text="12:14 AM",bg='white',fg='red',font=('sans serif',12))
                               lb2.place(x=280,y=60)
                               ####################label3##########################
                               lb3=Label(window,text="12:14 AM",bg='white',fg='green',font=('sans serif',12))
                               lb3.place(x=6,y=60)   
                               #####################this condition for less than 12 pm udate in train#############################
                           elif(hourse<=6 and (minute>=0 and am=='PM')):
                               z=30
                               while(z<620):
                                   
                                   f4=Frame(window,height="39",width="30")
                                   f4.place(x=91,y=z)
                                   img7=Label(f4,image=img6,bg='skyblue',width="26")
                                   img7.place(x=0,y=0)
                                   z=z+10
                                   ##################label2#############################
                                   lb2=Label(window,text="12:14 AM",bg='white',fg='red',font=('sans serif',12))
                                   lb2.place(x=280,y=60)
                                   ####################label3##########################
                                   lb3=Label(window,text="12:14 AM",bg='white',fg='green',font=('sans serif',12))
                                   lb3.place(x=9,y=60) 
                                   ###################label1############################
                                   l1=Label(window,text="2:22 AM",bg='white',fg='red',font=('sans serif',12))
                                   l1.place(x=291,y=330)
                                   ####################label4##########################
                                   lb4=Label(window,text="2:15 AM",bg="white",fg="green",font=('sans serif',12))
                                   lb4.place(x=9,y=330)
                                       
                                   lb2=Label(window,text="--",bg='white',font=('sans serif',20))
                                   lb2.place(x=320,y=640)
                                    ####################label3##########################
                                   lb3=Label(window,text="7:40 AM",bg='white',fg='green',font=('sans serif',12))
                                   lb3.place(x=9,y=640)
                           elif(hourse<=12 and (minute>=0 and am=='PM')):
                               z=30
                               while(z<=30):
                                   f4=Frame(window,height="39",width="30")
                                   f4.place(x=88,y=z)
                                   img7=Label(f4,image=img6,bg='skyblue',width="26")
                                   img7.place(x=0,y=0)
                                   z=z+10  
                           else:
                              print("wrong")
                       ########################bt5 for refresh to  prayagraj juction to new delhi ####################
                       bt5=Button(window,text="Refresh",bg="white",fg="green",font=('sans serif',12),command=refresh)
                       bt5.place(x=240,y=550)
              ###########################frame3#######################################
              f3=Frame(f1,height='68',width='360',bg='Dodger blue')
              f3.place(x=1,y=2)    
              def alldates():
                  master1 = Tk()
                  master1.maxsize(height="270",width="370")
                  master1.minsize(height="270",width="370")
                  # Tkinter string variable
                  # able to store any string value
                  v1 = StringVar(master1, "1")
                  mlb1=Label(master1,text=" Choose the date when the train starts from \n        Prayagraj junction             ",bg='skyblue',fg='white',font=('sans-serif',14))
                  mlb1.place(x=0,y=5)
                  Radiobutton(master1, text="All Dates", variable=v1, value=1,font=(20)).place(x=1,y=70)
                  def today():
                      tbt=Button(f3,text="  Today    ",font=(20))
                      tbt.place(x=40,y=20)
                  Radiobutton(master1, text="  Today  ", variable=v1, value=2,font=(20),command=today).place(x=1,y=100)
                  def tomorrow():
                      tobt=Button(f3,text="Tomorrow",font=(20))
                      tobt.place(x=40,y=20)
                  Radiobutton(master1, text="Tomorrow", variable=v1, value=3,font=(20),command=tomorrow).place(x=1,y=130)
                  def cfcalender():
                      # Create Object
                      root = Tk()
                      # Set geometry
                      root.geometry("400x400")
                      # Add Calendar
                      cal = Calendar(root, selectmode = 'day',year = 2023, month = 10,day = 22)
                      cal.pack(pady = 20)
                      root.mainloop()
                  Radiobutton(master1, text="Choose from Calendar", variable=v1, value=4,font=(20),command=cfcalender).place(x=1,y=160)
                  def cancel():                     
                      messagebox.showinfo("Cancle",'Ruko Jara Sabar Karo')
                  mbt=Button(master1,text='                      Cancel                          ',font=('sans-serif',16),bd=2,relief=RIDGE,command=cancel)
                  mbt.place(x=0,y=225)
              bt=Button(f3,text="All Dates",font=(20),command=alldates)
              bt.place(x=40,y=20)              
              def chfc():
                  master = Tk()
                  master.maxsize(height="400",width="300")
                  master.minsize(height="400",width="300")
                  # Tkinter string variable
                  # able to store any string value
                  v = StringVar(master, "1")
                  mlb1=Label(master,text="             Choose fare class              ",bg='skyblue',fg='white',font=('sans-serif',14))
                  mlb1.place(x=0,y=5)
                  def gu():
                      #messagebox.showinfo("Class",'GN - Unreserved')
                      glb1=Label(bt2,text="NA       ",font=('sans-serif',20),bg='white',fg='grey')
                      glb1.place(x=250,y=25)
                      glb2=Label(bt5,text="₹ 210     ",font=('sans-serif',20),bg='white',fg='grey')
                      glb2.place(x=250,y=25)
                      glb3=Label(bt8,text="₹ 210     ",font=('sans-serif',20),bg='white',fg='grey')
                      glb3.place(x=250,y=25)
                      glb4=Label(bt11,text="₹ 210     ",font=('sans-serif',20),bg='white',fg='grey')
                      glb4.place(x=250,y=25)
                  Radiobutton(master, text="GN - Unreserved", variable=v, value=1,font=(20),command=gu).place(x=1,y=40)
                  def ss():
                      #messagebox.showinfo("Class",'SL - Sleeper')
                      glb1=Label(bt2,text="NA  ",font=('sans-serif',20),bg='white',fg='grey')
                      glb1.place(x=250,y=25)
                      glb2=Label(bt5,text="₹ 390 ",font=('sans-serif',20),bg='white',fg='grey')
                      glb2.place(x=250,y=25)
                      glb3=Label(bt8,text="₹ 390 ",font=('sans-serif',20),bg='white',fg='grey')
                      glb3.place(x=250,y=25)
                      glb4=Label(bt11,text="₹ 385 ",font=('sans-serif',20),bg='white',fg='grey')
                      glb4.place(x=250,y=25)
                  Radiobutton(master, text="SL - Sleeper", variable=v, value=2,font=(20),command=ss).place(x=1,y=70)
                  def thac():                    
                      glb1=Label(bt2,text="NA",font=('sans-serif',20),bg='white',fg='grey')
                      glb1.place(x=250,y=25)
                      glb2=Label(bt5,text="₹ 1020",font=('sans-serif',20),bg='white',fg='grey')
                      glb2.place(x=250,y=25)
                      glb3=Label(bt8,text="₹ 1020",font=('sans-serif',20),bg='white',fg='grey')
                      glb3.place(x=250,y=25)
                      glb4=Label(bt11,text="₹ 1005",font=('sans-serif',20),bg='white',fg='grey')
                      glb4.place(x=250,y=25)
                  Radiobutton(master, text="3A - AC 3-Tier", variable=v, value=3,font=(20),command=thac).place(x=1,y=100)
                  def tac():
                      glb1=Label(bt2,text="NA   ",font=('sans-serif',20),bg='white',fg='grey')
                      glb1.place(x=250,y=25)
                      glb2=Label(bt5,text="₹ 1430 ",font=('sans-serif',20),bg='white',fg='grey')
                      glb2.place(x=250,y=25)
                      glb3=Label(bt8,text="₹ 1430 ",font=('sans-serif',20),bg='white',fg='grey')
                      glb3.place(x=250,y=25)
                      glb4=Label(bt11,text="₹ 1415 ",font=('sans-serif',20),bg='white',fg='grey')
                      glb4.place(x=250,y=25)   
                  Radiobutton(master, text="2A - AC 2-Tier", variable=v, value=4,font=(20),command=tac).place(x=1,y=130)
                  def oac():
                      glb1=Label(bt2,text="NA",font=('sans-serif',20),bg='white',fg='grey')
                      glb1.place(x=250,y=25)
                      glb2=Label(bt5,text="₹ 2390",font=('sans-serif',20),bg='white',fg='grey')
                      glb2.place(x=250,y=25)
                      glb3=Label(bt8,text="₹ 2390",font=('sans-serif',20),bg='white',fg='grey')
                      glb3.place(x=250,y=25)
                      glb4=Label(bt11,text="₹ 2360",font=('sans-serif',20),bg='white',fg='grey')
                      glb4.place(x=250,y=25)   
                  Radiobutton(master, text="1A - First Class AC", variable=v, value=5,font=(20),command=oac).place(x=1,y=160)
                  def ccac():  
                      glb1=Label(bt2,text="₹ 1110*",font=('sans-serif',20),bg='white',fg='grey')
                      glb1.place(x=250,y=25)
                      glb2=Label(bt5,text=" ₹ 830 ",font=('sans-serif',20),bg='white',fg='grey')
                      glb2.place(x=250,y=25)
                      glb3=Label(bt8,text=" ₹ 830 ",font=('sans-serif',20),bg='white',fg='grey')
                      glb3.place(x=250,y=25)
                      glb4=Label(bt11,text=" ₹ 820 ",font=('sans-serif',20),bg='white',fg='grey')
                      glb4.place(x=250,y=25)
                  Radiobutton(master, text="CC - AC Chair Car", variable=v, value=6,font=(20),command=ccac).place(x=1,y=190)
                  def ecc():
                      glb1=Label(bt2,text="₹ 2395*",font=('sans-serif',20),bg='white',fg='grey')
                      glb1.place(x=250,y=25)
                      glb2=Label(bt5,text=" ₹ NA  ",font=('sans-serif',20),bg='white',fg='grey')
                      glb2.place(x=250,y=25)
                      glb3=Label(bt8,text=" ₹ NA  ",font=('sans-serif',20),bg='white',fg='grey')
                      glb3.place(x=250,y=25)
                      glb4=Label(bt11,text=" ₹ NA  ",font=('sans-serif',20),bg='white',fg='grey')
                      glb4.place(x=250,y=25)
                  Radiobutton(master, text="EC - Executive Chair Car", variable=v, value=7,font=(20),command=ecc).place(x=1,y=220)
                  def tsss():        
                      glb1=Label(bt2,text=" ₹ NA  ",font=('sans-serif',20),bg='white',fg='grey')
                      glb1.place(x=250,y=25)
                      glb2=Label(bt5,text=" ₹ 225 ",font=('sans-serif',20),bg='white',fg='grey')
                      glb2.place(x=250,y=25)
                      glb3=Label(bt8,text=" ₹ 225 ",font=('sans-serif',20),bg='white',fg='grey')
                      glb3.place(x=250,y=25)
                      glb4=Label(bt11,text=" ₹ 225 ",font=('sans-serif',20),bg='white',fg='grey')
                      glb4.place(x=250,y=25)    
                  Radiobutton(master, text="2S - Second Sitting", variable=v, value=8,font=(20),command=tsss).place(x=1,y=250)
                  def fcfc():       
                      glb1=Label(bt2,text=" ₹ NA  ",font=('sans-serif',20),bg='white',fg='grey')
                      glb1.place(x=250,y=25)
                      glb2=Label(bt5,text=" ₹ 1155",font=('sans-serif',20),bg='white',fg='grey')
                      glb2.place(x=250,y=25)
                      glb3=Label(bt8,text=" ₹ 1155",font=('sans-serif',20),bg='white',fg='grey')
                      glb3.place(x=250,y=25)
                      glb4=Label(bt11,text=" ₹ 1145",font=('sans-serif',20),bg='white',fg='grey')
                      glb4.place(x=250,y=25)
                  Radiobutton(master, text="FC - First Class", variable=v, value=9,font=(20),command=fcfc).place(x=1,y=280)
                  def hf():
                      glb1=Label(bt2,text="          ",font=('sans-serif',20),bg='white',fg='grey')
                      glb1.place(x=250,y=25)
                      glb2=Label(bt5,text="           ",font=('sans-serif',20),bg='white',fg='grey')
                      glb2.place(x=250,y=25)
                      glb3=Label(bt8,text="           ",font=('sans-serif',20),bg='white',fg='grey')
                      glb3.place(x=250,y=25)
                      glb4=Label(bt11,text="           ",font=('sans-serif',20),bg='white',fg='grey')
                      glb4.place(x=250,y=25)
                  Radiobutton(master, text="Hide fares", variable=v, value=10,font=(20),command=hf).place(x=1,y=310)
                  def cancel():
                      messagebox.showinfo("Cancle",'Ruko Jara Sabar Karo')
                  mbt1=Button(master,text='                 Cancel                       ',font=('sans-serif',16),bd=2,relief=RIDGE,command=cancel)
                  mbt1.place(x=0,y=355)
              #########################bt1 for Train class################################
              bt1=Button(f3,text="GN - Unreserved",font=(20),command=chfc)
              bt1.place(x=170,y=20)  
              ###########################label6########################################
              lb5=Label(f1,text="PRYJ  -   Prayagraj     ->    NDLS  -   New \n                         Juction                                 Delhi ",font=('impact',17),fg='white',bg='Dodger blue')
              lb5.place(x=1,y=71)
              #############################bt2 for Express name###########################
              bt2=Button(f1,text="  12:12 AM -> 7:40AM \n\nNew Delhi Tejas Rajdhani                    \n  Express                           ",font=('sans serif',15),bg="white",command=pjnd)
              bt2.place(x=1,y=135)
              #############################lb3 for train number################################
              lb3=Label(bt2,text='12309',bg="Dodger blue",font=('sans serif ',14),fg="white")
              lb3.place(x=0,y=5)
              ################################lb4 for runs daily#################################
              lb4=Label(bt2,text="Runs Daily",font=("sans serif",14),fg="Dodger blue",bg="white")
              lb4.place(x=249,y=66)   
              def mjnd():
                  window1=Toplevel()
                  window1.title('Praygraj to New Delhi Update')
                  window1.maxsize(height="740",width="360")
                  window1.minsize(height="740",width="360")
                  f2=Frame(window1,height="690",width="360",bg="red")
                  f2.place(x=0,y=0)
                  img9=Label(f2,image=img8)
                  img9.pack()
                  def refresh():
                      if(hourse<=12 and (minute>=0 and am=='AM')):
                          f4=Frame(window1,height="39",width="30")
                          f4.place(x=88,y=30)
                          img7=Label(f4,image=img6,bg='skyblue',width="26")
                          img7.place(x=0,y=0)
                          if(hourse==1 and (minute<=30 and am=='AM')):
                              z=30
                              while(z<=60):
                                  f4=Frame(window1,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                          elif(hourse==1 and (minute<=59 and am=='AM')):
                              z=30
                              while(z<=80):
                                  f4=Frame(window1,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+1
                          elif(hourse==2 and (minute<=30 and am=='AM')):
                              z=30
                              while(z<=100):
                                  f4=Frame(window1,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                          elif(hourse==2 and (minute<=59 and am=='AM')):
                              z=30
                              while(z<=120):
                                  f4=Frame(window1,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+1
                          elif(hourse==3 and (minute<=30 and am=='AM')):
                              z=30
                              while(z<=140):
                                  f4=Frame(window1,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                          elif(hourse==3 and (minute<=59 and am=='AM')):
                              z=30
                              while(z<=200):
                                  f4=Frame(window1,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                  ##################label2#############################
                                  lb4=Label(window1,text="3:45 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb4.place(x=5,y=230)
                                  ####################label3##########################
                                  lb5=Label(window1,text="3:59 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=290,y=230)                              
                          elif(hourse==4 and (minute<=30 and am=='AM')):
                              z=30
                              while(z<=240):
                                  f4=Frame(window1,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+1
                                  ##################label2#############################
                                  lb4=Label(window1,text="3:45 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb4.place(x=5,y=230)
                                  ####################label3##########################
                                  lb5=Label(window1,text="3:59 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=290,y=230)
                          elif(hourse==4 and (minute<=59 and am=='AM')):
                              z=30
                              while(z<=260):
                                  f4=Frame(window1,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                  ##################label2#############################
                                  lb4=Label(window1,text="3:45 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb4.place(x=5,y=230)
                                  ####################label3##########################
                                  lb5=Label(window1,text="3:59 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=290,y=230)
                          elif(hourse==5 and (minute<=59 and am=='AM')):
                              z=30
                              while(z<=310):
                                  f4=Frame(window1,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                  ##################label2#############################
                                  lb4=Label(window1,text="3:45 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb4.place(x=5,y=230)
                                  ####################label3##########################
                                  lb5=Label(window1,text="3:59 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=290,y=230)
                                  ##################label2#############################
                                  lb6=Label(window1,text="5:28 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=7,y=340)
                                  ####################label3##########################
                                  lb7=Label(window1,text="5:49 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb7.place(x=292,y=340)
                          elif(hourse==6 and (minute<=20 and am=='AM')):
                              z=30
                              while(z<=350):
                                  f4=Frame(window1,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                  ##################label2#############################
                                  lb4=Label(window1,text="3:45 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb4.place(x=5,y=230)
                                  ####################label3##########################
                                  lb5=Label(window1,text="3:59 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=290,y=230)
                                  ##################label2#############################
                                  lb6=Label(window1,text="5:28 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=7,y=340)
                                  ####################label3##########################
                                  lb7=Label(window1,text="5:49 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb7.place(x=292,y=340)    
                          elif(hourse==6 and (minute<=50 and am=='AM')):
                              z=30
                              while(z<=440):
                                  f4=Frame(window1,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                  ##################label4#############################
                                  lb4=Label(window1,text="3:45 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb4.place(x=5,y=230)
                                  ####################label5##########################
                                  lb5=Label(window1,text="3:59 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=290,y=230)
                                  ##################label6#############################
                                  lb6=Label(window1,text="5:28 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=7,y=340)
                                  ####################label7##########################
                                  lb7=Label(window1,text="5:49 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb7.place(x=292,y=340)
                                  ##################label8#############################
                                  lb8=Label(window1,text="6:15 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb8.place(x=5,y=470)
                                  ####################label9##########################
                                  lb9=Label(window1,text="6:36 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb9.place(x=290,y=470)
                          elif(hourse==7 and (minute<=20 and am=='AM')):
                              z=30
                              while(z<=510):
                                  f4=Frame(window1,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                  ##################label4#############################
                                  lb4=Label(window1,text="3:45 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb4.place(x=5,y=230)
                                  ####################label5##########################
                                  lb5=Label(window1,text="3:59 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=290,y=230)
                                  ##################label6#############################
                                  lb6=Label(window1,text="5:28 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=7,y=340)
                                  ####################label7##########################
                                  lb7=Label(window1,text="5:49 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb7.place(x=292,y=340)
                                  ##################label8#############################
                                  lb8=Label(window1,text="6:15 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb8.place(x=8,y=470)
                                  ####################label9##########################
                                  lb9=Label(window1,text="6:36 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb9.place(x=290,y=470)
                                  ##################label10#############################
                                  lb10=Label(window1,text="6:53 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb10.place(x=8,y=540)
                                  ####################label11##########################
                                  lb11=Label(window1,text="7:10 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb11.place(x=290,y=540)
                          elif(hourse==7 and (minute<=59 and am=='AM')):
                              z=30
                              while(z<=590):
                                  f4=Frame(window1,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                  ##################label4#############################
                                  lb4=Label(window1,text="3:45 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb4.place(x=5,y=230)
                                  ####################label5##########################
                                  lb5=Label(window1,text="3:59 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=290,y=230)
                                  ##################label6#############################
                                  lb6=Label(window1,text="5:28 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=7,y=340)
                                  ####################label7##########################
                                  lb7=Label(window1,text="5:49 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb7.place(x=292,y=340)
                                  ##################label8#############################
                                  lb8=Label(window1,text="6:15 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb8.place(x=8,y=470)
                                  ####################label9##########################
                                  lb9=Label(window1,text="6:36 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb9.place(x=290,y=470)
                                  ##################label10#############################
                                  lb10=Label(window1,text="6:53 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb10.place(x=8,y=540)
                                  ####################label11##########################
                                  lb11=Label(window1,text="7:10 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb11.place(x=290,y=540)
                                  ##################label11#############################
                                  lb11=Label(window1,text="7:50 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb11.place(x=8,y=620)
                                  ####################label12##########################
                                  lb12=Label(window1,text="8:00 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb12.place(x=290,y=620)
                          elif(hourse==8 and (minute<=59 and am=='AM')):
                              z=30
                              while(z<=600):
                                  f4=Frame(window1,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                  ##################label4#############################
                                  lb4=Label(window1,text="3:45 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb4.place(x=5,y=230)
                                  ####################label5##########################
                                  lb5=Label(window1,text="3:59 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=290,y=230)
                                  ##################label6#############################
                                  lb6=Label(window1,text="5:28 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=7,y=340)
                                  ####################label7##########################
                                  lb7=Label(window1,text="5:49 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb7.place(x=292,y=340)
                                  ##################label8#############################
                                  lb8=Label(window1,text="6:15 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb8.place(x=8,y=470)
                                  ####################label9##########################
                                  lb9=Label(window1,text="6:36 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb9.place(x=290,y=470)
                                  ##################label10#############################
                                  lb10=Label(window1,text="6:53 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb10.place(x=8,y=540)
                                  ####################label11##########################
                                  lb11=Label(window1,text="7:10 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb11.place(x=290,y=540)
                                  ##################label11#############################
                                  lb11=Label(window1,text="7:50 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb11.place(x=8,y=620)
                                  ####################label12##########################
                                  lb12=Label(window1,text="8:00 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb12.place(x=290,y=620)
                          elif(hourse==9 and (minute<=59 and am=='AM')):
                              z=30
                              while(z<=620):
                                  f4=Frame(window1,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                  ##################label4#############################
                                  lb4=Label(window1,text="3:45 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb4.place(x=5,y=230)
                                  ####################label5##########################
                                  lb5=Label(window1,text="3:59 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=290,y=230)
                                  ##################label6#############################
                                  lb6=Label(window1,text="5:28 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=7,y=340)
                                  ####################label7##########################
                                  lb7=Label(window1,text="5:49 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb7.place(x=292,y=340)
                                  ##################label8#############################
                                  lb8=Label(window1,text="6:15 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb8.place(x=8,y=470)
                                  ####################label9##########################
                                  lb9=Label(window1,text="6:36 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb9.place(x=290,y=470)
                                  ##################label10#############################
                                  lb10=Label(window1,text="6:53 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb10.place(x=8,y=540)
                                  ####################label11##########################
                                  lb11=Label(window1,text="7:10 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb11.place(x=290,y=540)
                                  ##################label11#############################
                                  lb11=Label(window1,text="7:50 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb11.place(x=8,y=620)
                                  ####################label12##########################
                                  lb12=Label(window1,text="8:00 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb12.place(x=290,y=620)
                          elif(hourse==10 and (minute<=59 and am=='AM')):
                              z=30
                              while(z<=630):
                                  f4=Frame(window1,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                  ##################label4#############################
                                  lb4=Label(window1,text="3:45 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb4.place(x=5,y=230)
                                  ####################label5##########################
                                  lb5=Label(window1,text="3:59 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=290,y=230)
                                  ##################label6#############################
                                  lb6=Label(window1,text="5:28 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=7,y=340)
                                  ####################label7##########################
                                  lb7=Label(window1,text="5:49 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb7.place(x=292,y=340)
                                  ##################label8#############################
                                  lb8=Label(window1,text="6:15 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb8.place(x=8,y=470)
                                  ####################label9##########################
                                  lb9=Label(window1,text="6:36 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb9.place(x=290,y=470)
                                  ##################label10#############################
                                  lb10=Label(window1,text="6:53 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb10.place(x=8,y=540)
                                  ####################label11##########################
                                  lb11=Label(window1,text="7:10 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb11.place(x=290,y=540)
                                  ##################label11#############################
                                  lb11=Label(window1,text="7:50 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb11.place(x=8,y=620)
                                  ####################label12##########################
                                  lb12=Label(window1,text="8:00 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb12.place(x=290,y=620)
                          elif(hourse==11 and (minute<=59 and am=='AM')):
                              z=30
                              while(z<=660):
                                  f4=Frame(window1,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                  ##################label4#############################
                                  lb4=Label(window1,text="3:45 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb4.place(x=5,y=230)
                                  ####################label5##########################
                                  lb5=Label(window1,text="3:59 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=290,y=230)
                                  ##################label6#############################
                                  lb6=Label(window1,text="5:28 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=7,y=340)
                                  ####################label7##########################
                                  lb7=Label(window1,text="5:49 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb7.place(x=292,y=340)
                                  ##################label8#############################
                                  lb8=Label(window1,text="6:15 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb8.place(x=8,y=470)
                                  ####################label9##########################
                                  lb9=Label(window1,text="6:36 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb9.place(x=290,y=470)
                                  ##################label10#############################
                                  lb10=Label(window1,text="6:53 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb10.place(x=8,y=540)
                                  ####################label11##########################
                                  lb11=Label(window1,text="7:10 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb11.place(x=290,y=540)
                                  ##################label11#############################
                                  lb11=Label(window1,text="7:50 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb11.place(x=8,y=620)
                                  ####################label12##########################
                                  lb12=Label(window1,text="8:00 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb12.place(x=290,y=620)
                                  ##################label13#############################
                                  lb13=Label(window1,text="11:50 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb13.place(x=8,y=690)
                                  ####################label14##########################
                                  lb14=Label(window1,text="--",bg='white',fg='black',font=('sans serif',15))
                                  lb14.place(x=310,y=680)
                           ##################label2#############################
                          lb2=Label(window1,text="1:40 AM",bg='white',fg='red',font=('sans serif',12))
                          lb2.place(x=291,y=60)
                          ####################label3##########################
                          lb3=Label(window1,text="1:15 AM",bg='white',fg='green',font=('sans serif',12))
                          lb3.place(x=5,y=60)  
                      elif(hourse<=6 and (minute<=59 and am=='PM')):
                              z=30
                              while(z<=660):
                                  f4=Frame(window1,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                  ##################label2#############################
                                  lb2=Label(window1,text="1:40 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=291,y=60)
                                  ####################label3##########################
                                  lb3=Label(window1,text="1:15 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=5,y=60)  
                                  ##################label4#############################
                                  lb4=Label(window1,text="3:45 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb4.place(x=5,y=230)
                                  ####################label5##########################
                                  lb5=Label(window1,text="3:59 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=290,y=230)
                                  ##################label6#############################
                                  lb6=Label(window1,text="5:28 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=7,y=340)
                                  ####################label7##########################
                                  lb7=Label(window1,text="5:49 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb7.place(x=292,y=340)
                                  ##################label8#############################
                                  lb8=Label(window1,text="6:15 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb8.place(x=8,y=470)
                                  ####################label9##########################
                                  lb9=Label(window1,text="6:36 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb9.place(x=290,y=470)
                                  ##################label10#############################
                                  lb10=Label(window1,text="6:53 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb10.place(x=8,y=540)
                                  ####################label11##########################
                                  lb11=Label(window1,text="7:10 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb11.place(x=290,y=540)
                                  ##################label11#############################
                                  lb12=Label(window1,text="7:50 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb12.place(x=8,y=620)
                                  ####################label12##########################
                                  lb13=Label(window1,text="8:00 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb13.place(x=290,y=620)
                                  ##################label13#############################
                                  lb14=Label(window1,text="11:50 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb14.place(x=8,y=690)
                                  ####################label14##########################
                                  lb15=Label(window1,text="--",bg='white',fg='black',font=('sans serif',15))
                                  lb15.place(x=310,y=680)
                      elif(hourse<=12 and (minute>=0 and am=='PM')):
                              f4=Frame(window1,height="39",width="30")
                              f4.place(x=88,y=30)
                              img7=Label(f4,image=img6,bg='skyblue',width="26")
                              img7.place(x=0,y=0)              
                 ########################bt5 for refresh to  prayagraj juction to new delhi ####################
                  bt5=Button(window1,text="Refresh",fg="white",bg="green",font=('sans serif',12),command=refresh)
                  bt5.place(x=240,y=565)                     
              #############################bt5 for Express name###########################
              bt5=Button(f1,text="      1:20 AM -> 11:50 AM   \n\nMagadh Express                                 \n",font=('sans serif',15),bg="white",command=mjnd)
              bt5.place(x=1,y=245)
              #############################lb6 for train number################################
              lb6=Label(bt5,text='12417',bg="Dodger blue",font=('sans serif ',14),fg="white")
              lb6.place(x=0,y=5)
              ################################lb6 for runs daily#################################
              lb7=Label(bt5,text="Runs Daily",font=("sans serif",14),fg="Dodger blue",bg="white")
              lb7.place(x=249,y=66)
              def ssnd():
                  window2=Toplevel()
                  window2.title('Praygraj to New Delhi Update')
                  window2.maxsize(height="700",width="360")
                  window2.minsize(height="700",width="360")
                  f2=Frame(window2,height="690",width="360",bg="red")
                  f2.place(x=0,y=0)
                  img11=Label(f2,image=img10)
                  img11.pack()
                  def refresh():
                      if(hourse<=12 and (minute>=0 and am=='AM')):
                          f4=Frame(window2,height="39",width="30")
                          f4.place(x=88,y=30)
                          img7=Label(f4,image=img6,bg='skyblue',width="26")
                          img7.place(x=0,y=0)
                          if(hourse==7 and (minute<=30 and am=='AM')):
                              z=30
                              while(z<=30):
                                  f4=Frame(window2,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                  ##################label2#############################
                                  lb2=Label(window2,text="7:30 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=291,y=60)
                                  ####################label3##########################
                                  lb3=Label(window2,text="7:10 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=5,y=60)
                          elif(hourse==7 and (minute<=59 and am=='AM')):
                              z=30
                              while(z<=60):
                                  f4=Frame(window2,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                  ##################label2#############################
                                  lb2=Label(window2,text="7:30 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=291,y=60)
                                  ####################label3##########################
                                  lb3=Label(window2,text="7:10 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=5,y=60)
                          elif(hourse==8 and (minute<=30 and am=='AM')):
                              z=30
                              while(z<=90):
                                  f4=Frame(window2,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                  ##################label2#############################
                                  lb2=Label(window2,text="7:30 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=291,y=60)
                                  ####################label3##########################
                                  lb3=Label(window2,text="7:10 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=5,y=60)
                          elif(hourse==8 and (minute<=59 and am=='AM')):
                              z=30
                              while(z<=120):
                                  f4=Frame(window2,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                  ##################label2#############################
                                  lb2=Label(window2,text="7:30 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=291,y=60)
                                  ####################label3##########################
                                  lb3=Label(window2,text="7:10 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=5,y=60)
                          elif(hourse==9 and (minute<=30 and am=='AM')):
                              z=30
                              while(z<=150):
                                  f4=Frame(window2,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                  ##################label2#############################
                                  lb2=Label(window2,text="7:30 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=291,y=60)
                                  ####################label3##########################
                                  lb3=Label(window2,text="7:10 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=5,y=60)
                          elif(hourse==9 and (minute<=59 and am=='AM')):
                              z=30
                              while(z<=190):
                                  f4=Frame(window2,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                  ##################label2#############################
                                  lb2=Label(window2,text="7:30 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=291,y=60)
                                  ####################label3##########################
                                  lb3=Label(window2,text="7:10 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=5,y=60)
                                  ##################label4#############################
                                  lb4=Label(window2,text="9:50 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb4.place(x=291,y=220)
                                  ####################label5##########################
                                  lb5=Label(window2,text="9:35 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb5.place(x=5,y=220)
                          elif(hourse==10 and (minute<=30 and am=='AM')):
                              z=30
                              while(z<=220):
                                  f4=Frame(window2,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                  ##################label2#############################
                                  lb2=Label(window2,text="7:30 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=291,y=60)
                                  ####################label3##########################
                                  lb3=Label(window2,text="7:10 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=5,y=60)
                                  ##################label4#############################
                                  lb4=Label(window2,text="9:50 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb4.place(x=291,y=220)
                                  ####################label5##########################
                                  lb5=Label(window2,text="9:35 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb5.place(x=5,y=220)
                          elif(hourse==10 and (minute<=59 and am=='AM')):
                              z=30
                              while(z<=250):
                                  
                                  f4=Frame(window2,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                  ##################label2#############################
                                  lb2=Label(window2,text="7:30 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=291,y=60)
                                  ####################label3##########################
                                  lb3=Label(window2,text="7:10 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=5,y=60)
                                  ##################label4#############################
                                  lb4=Label(window2,text="9:50 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb4.place(x=291,y=220)
                                  ####################label5##########################
                                  lb5=Label(window2,text="9:35 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb5.place(x=5,y=220)
                          elif(hourse==11 and (minute<=30 and am=='AM')):
                              z=30
                              while(z<=280):
                                          f4=Frame(window2,height="39",width="30")
                                          f4.place(x=88,y=z)
                                          img7=Label(f4,image=img6,bg='skyblue',width="26")
                                          img7.place(x=0,y=0)
                                          z=z+10
                                          ##################label2#############################
                                          lb2=Label(window2,text="7:30 AM",bg='white',fg='red',font=('sans serif',12))
                                          lb2.place(x=291,y=60)
                                          ####################label3##########################
                                          lb3=Label(window2,text="7:10 AM",bg='white',fg='green',font=('sans serif',12))
                                          lb3.place(x=5,y=60)
                                          ##################label4#############################
                                          lb4=Label(window2,text="9:50 AM",bg='white',fg='red',font=('sans serif',12))
                                          lb4.place(x=291,y=220)
                                          ####################label5##########################
                                          lb5=Label(window2,text="9:35 AM",bg='white',fg='green',font=('sans serif',12))
                                          lb5.place(x=5,y=220)
                          elif(hourse==11 and (minute<=59 and am=='AM')):
                                      z=30
                                      while(z<=310):
                                          f4=Frame(window2,height="39",width="30")
                                          f4.place(x=88,y=z)
                                          img7=Label(f4,image=img6,bg='skyblue',width="26")
                                          img7.place(x=0,y=0)
                                          z=z+10
                                          ##################label2#############################
                                          lb2=Label(window2,text="7:30 AM",bg='white',fg='red',font=('sans serif',12))
                                          lb2.place(x=291,y=60)
                                          ####################label3##########################
                                          lb3=Label(window2,text="7:10 AM",bg='white',fg='green',font=('sans serif',12))
                                          lb3.place(x=5,y=60)
                                          ##################label4#############################
                                          lb4=Label(window2,text="9:50 AM",bg='white',fg='red',font=('sans serif',12))
                                          lb4.place(x=291,y=220)
                                          ####################label5##########################
                                          lb5=Label(window2,text="9:35 AM",bg='white',fg='green',font=('sans serif',12))
                                          lb5.place(x=5,y=220)
                      elif(hourse<=12 and (minute>=0 and am=='PM')):
                          f4=Frame(window2,height="39",width="30")
                          f4.place(x=88,y=30)
                          img7=Label(f4,image=img6,bg='skyblue',width="26")
                          img7.place(x=0,y=0)
                          if(hourse==12 and (minute<=30 and am=='PM')):                             
                              z=30
                              while(z<=340):                                 
                                  f4=Frame(window2,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                  ##################label2#############################
                                  lb2=Label(window2,text="7:30 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=291,y=60)
                                  ####################label3##########################
                                  lb3=Label(window2,text="7:10 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=5,y=60)
                                  ##################label4#############################
                                  lb4=Label(window2,text="9:50 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb4.place(x=291,y=220)
                                  ####################label5##########################
                                  lb5=Label(window2,text="9:35 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb5.place(x=5,y=220)
                          elif(hourse==12 and (minute<=59 and am=='PM')):
                              z=30
                              while(z<=310):
                                  f4=Frame(window2,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                  ##################label2#############################
                                  lb2=Label(window2,text="7:30 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=291,y=60)
                                  ####################label3##########################
                                  lb3=Label(window2,text="7:10 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=5,y=60)
                                  ##################label4#############################
                                  lb4=Label(window2,text="9:50 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb4.place(x=291,y=220)
                                  ####################label5##########################
                                  lb5=Label(window2,text="9:35 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb5.place(x=5,y=220)                                         
                          elif(hourse==1 and (minute<=30 and am=='PM')):
                              z=30
                              while(z<=420):
                                  f4=Frame(window2,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                  ##################label2#############################
                                  lb2=Label(window2,text="7:30 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=291,y=60)
                                  ####################label3##########################
                                  lb3=Label(window2,text="7:10 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=5,y=60)
                                  ##################label4#############################
                                  lb4=Label(window2,text="9:50 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb4.place(x=291,y=220)
                                  ####################label5##########################
                                  lb5=Label(window2,text="9:35 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb5.place(x=5,y=220)
                                  ##################label6#############################
                                  lb6=Label(window2,text="1:15 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb6.place(x=291,y=450)
                                  ####################label7##########################
                                  lb7=Label(window2,text="1:08 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb7.place(x=5,y=450)
                          elif(hourse==1 and (minute<=59 and am=='PM')):
                              z=30
                              while(z<=450):
                                  f4=Frame(window2,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                  ##################label2#############################
                                  lb2=Label(window2,text="7:30 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=291,y=60)
                                  ####################label3##########################
                                  lb3=Label(window2,text="7:10 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=5,y=60)
                                  ##################label4#############################
                                  lb4=Label(window2,text="9:50 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb4.place(x=291,y=220)
                                  ####################label5##########################
                                  lb5=Label(window2,text="9:35 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb5.place(x=5,y=220)
                                  ##################label6#############################
                                  lb6=Label(window2,text="1:15 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb6.place(x=291,y=450)
                                  ####################label7##########################
                                  lb7=Label(window2,text="1:08 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb7.place(x=5,y=450)
                          elif(hourse==2 and (minute<=30 and am=='PM')):
                              z=30
                              while(z<=480):
                                  f4=Frame(window2,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                  ##################label2#############################
                                  lb2=Label(window2,text="7:30 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=291,y=60)
                                  ####################label3##########################
                                  lb3=Label(window2,text="7:10 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=5,y=60)
                                  ##################label4#############################
                                  lb4=Label(window2,text="9:50 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb4.place(x=291,y=220)
                                  ####################label5##########################
                                  lb5=Label(window2,text="9:35 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb5.place(x=5,y=220)
                                  ##################label6#############################
                                  lb6=Label(window2,text="1:15 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb6.place(x=291,y=450)
                                  ####################label7##########################
                                  lb7=Label(window2,text="1:08 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb7.place(x=5,y=450)
                          elif(hourse==2 and (minute>=48 and am=='PM')):
                              z=30
                              while(z<=520):
                                  f4=Frame(window2,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                  ##################label2#############################
                                  lb2=Label(window2,text="7:30 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=291,y=60)
                                  ####################label3##########################
                                  lb3=Label(window2,text="7:10 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=5,y=60)
                                  ##################label4#############################
                                  lb4=Label(window2,text="9:50 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb4.place(x=291,y=220)
                                  ####################label5##########################
                                  lb5=Label(window2,text="9:35 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb5.place(x=5,y=220)
                                  ##################label6#############################
                                  lb6=Label(window2,text="1:15 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb6.place(x=291,y=450)
                                  ####################label7##########################
                                  lb7=Label(window2,text="2:48 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb7.place(x=5,y=450)
                                  ##################label8#############################
                                  lb8=Label(window2,text="--",bg='white',fg='black',font=('sans serif',16))
                                  lb8.place(x=301,y=560)
                                  ####################label9##########################
                                  lb9=Label(window2,text="1:08 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb9.place(x=5,y=560)
                          elif(hourse==3 and (minute<=30 and am=='PM')):
                              z=30
                              while(z<=570):
                                  f4=Frame(window2,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                  ##################label2#############################
                                  lb2=Label(window2,text="7:30 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=291,y=60)
                                  ####################label3##########################
                                  lb3=Label(window2,text="7:10 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=5,y=60)
                                  ##################label4#############################
                                  lb4=Label(window2,text="9:50 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb4.place(x=291,y=220)
                                  ####################label5##########################
                                  lb5=Label(window2,text="9:35 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb5.place(x=5,y=220)
                                  ##################label6#############################
                                  lb6=Label(window2,text="1:15 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb6.place(x=291,y=450)
                                  ####################label7##########################
                                  lb7=Label(window2,text="2:48 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb7.place(x=5,y=450)
                                  ##################label8#############################
                                  lb8=Label(window2,text="--",bg='white',fg='black',font=('sans serif',16))
                                  lb8.place(x=301,y=560)
                                  ####################label9##########################
                                  lb9=Label(window2,text="1:08 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb9.place(x=5,y=560)
                          elif(hourse<=6 and (minute<=59 and am=='PM')):
                              z=30
                              while(z<=610):
                                  f4=Frame(window2,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                  ##################label2#############################
                                  lb2=Label(window2,text="7:30 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=291,y=60)
                                  ####################label3##########################
                                  lb3=Label(window2,text="7:10 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=5,y=60)
                                  ##################label4#############################
                                  lb4=Label(window2,text="9:50 AM",bg='white',fg='red',font=('sans serif',12))
                                  lb4.place(x=291,y=220)
                                  ####################label5##########################
                                  lb5=Label(window2,text="9:35 AM",bg='white',fg='green',font=('sans serif',12))
                                  lb5.place(x=5,y=220)
                                  ##################label6#############################
                                  lb6=Label(window2,text="1:15 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb6.place(x=291,y=450)
                                  ####################label7##########################
                                  lb7=Label(window2,text="2:48 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb7.place(x=5,y=450)
                                  ##################label8#############################
                                  lb8=Label(window2,text="--",bg='white',fg='black',font=('sans serif',16))
                                  lb8.place(x=301,y=560)
                                  ####################label9##########################
                                  lb9=Label(window2,text="2:48 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb9.place(x=5,y=560)
                                  ##################label10#############################
                                  lb10=Label(window2,text="--",bg='white',fg='black',font=('sans serif',16))
                                  lb10.place(x=301,y=640)
                                  ####################label11##########################
                                  lb11=Label(window2,text="3:40 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb11.place(x=5,y=640)                                                      
                  ########################bt5 for refresh to  prayagraj juction to new delhi ####################
                  bt11=Button(window2,text="Refresh",fg="white",bg="green",font=('sans serif',12),command=refresh)
                  bt11.place(x=230,y=585)    
              #############################bt8 for Express name###########################
              bt8=Button(f1,text="      7:10 AM -> 3:40 PM   \n\nSwatantra Senani Express                   \n",font=('sans serif',15),bg="white",command=ssnd)
              bt8.place(x=1,y=355)
              #############################lb9 for train number################################
              lb9=Label(bt8,text='12561',bg="Dodger blue",font=('sans serif ',14),fg="white")
              lb9.place(x=0,y=5)
              ################################lb10 for runs daily#################################
              lb10=Label(bt8,text="Runs Daily",font=("sans serif",14),fg="Dodger blue",bg="white")
              lb10.place(x=249,y=66)
              def nend():
                  window3=Toplevel()
                  window3.title('Praygraj to New Delhi Update')
                  window3.maxsize(height="700",width="360")
                  window3.minsize(height="700",width="360")
                  f2=Frame(window3,height="690",width="360",bg="red")
                  f2.place(x=0,y=0)
                  img13=Label(f2,image=img12)
                  img13.pack()
                  def refresh():
                      if(hourse<=12 and (minute>=0 and am=='PM')):
                          f4=Frame(window3,height="39",width="30")
                          f4.place(x=88,y=30)
                          img7=Label(f4,image=img6,bg='skyblue',width="26")
                          img7.place(x=0,y=0)
                          
                          if(hourse==12 and (minute<=59 and am=='PM')):
                              f4=Frame(window3,height="39",width="30")
                              f4.place(x=88,y=30)
                              img7=Label(f4,image=img6,bg='skyblue',width="26")
                              img7.place(x=0,y=0)
                               ##################label2#############################
                              lb2=Label(window3,text="12:50 PM",bg='white',fg='red',font=('sans serif',12))
                              lb2.place(x=281,y=60)
                              ####################label3##########################
                              lb3=Label(window3,text="12:25 PM",bg='white',fg='green',font=('sans serif',12))
                              lb3.place(x=7,y=60)
                        
                          elif(hourse==1 and (minute<=59 and am=='PM')):
                               z=30
                               while(z<=60):
                                  f4=Frame(window3,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                   ####################label2##########################
                                  lb2=Label(window3,text="12:50 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=281,y=60)
                                  ####################label3##########################
                                  lb3=Label(window3,text="12:25 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=7,y=60)
                          elif(hourse==2 and (minute<=10 and am=='PM')):
                               z=30
                               while(z<=80):
                                  f4=Frame(window3,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                   ####################label2##########################
                                  lb2=Label(window3,text="12:50 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=281,y=60)
                                  ####################label3##########################
                                  lb3=Label(window3,text="12:25 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=7,y=60) 
                          elif(hourse==2 and (minute>=10 and am=='PM')): 
                              z=30
                              while(z<=100):
                                  f4=Frame(window3,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                   ####################label2##########################
                                  lb2=Label(window3,text="12:50 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=281,y=60)
                                  ####################label3##########################
                                  lb3=Label(window3,text="12:25 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=7,y=60)
                                  ####################label4##########################
                                  lb4=Label(window3,text="2:10 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb4.place(x=281,y=130)
                                  ####################label5##########################
                                  lb5=Label(window3,text="1:38 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb5.place(x=6,y=130)
                          elif(hourse==2 and (minute<=59 and am=='PM')): 
                              z=30
                              while(z<=150):
                                  f4=Frame(window3,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                   ####################label2##########################
                                  lb2=Label(window3,text="12:50 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=281,y=60)
                                  ####################label3##########################
                                  lb3=Label(window3,text="12:25 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=7,y=60)
                                  ####################label4##########################
                                  lb4=Label(window3,text="2:10 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb4.place(x=281,y=130)
                                  ####################label5##########################
                                  lb5=Label(window3,text="1:38 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb5.place(x=6,y=130)
                          elif(hourse==3 and (minute<=30 and am=='PM')): 
                              z=30
                              while(z<=190):
                                  f4=Frame(window3,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                   ####################label2##########################
                                  lb2=Label(window3,text="12:50 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=281,y=60)
                                  ####################label3##########################
                                  lb3=Label(window3,text="12:25 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=7,y=60)
                                  ####################label4##########################
                                  lb4=Label(window3,text="2:10 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb4.place(x=281,y=130)
                                  ####################label5##########################
                                  lb5=Label(window3,text="1:38 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb5.place(x=6,y=130)
                                  ####################label5##########################
                                  lb5=Label(window3,text="3:25 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=291,y=220)
                                  ####################label6##########################
                                  lb6=Label(window3,text="3:00 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=6,y=220)
                          elif(hourse==3 and (minute<=59 and am=='PM')): 
                              z=30
                              while(z<=220):
                                  f4=Frame(window3,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                   ####################label2##########################
                                  lb2=Label(window3,text="12:50 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=281,y=60)
                                  ####################label3##########################
                                  lb3=Label(window3,text="12:25 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=7,y=60)
                                  ####################label4##########################
                                  lb4=Label(window3,text="2:10 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb4.place(x=281,y=130)
                                  ####################label5##########################
                                  lb5=Label(window3,text="1:38 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb5.place(x=6,y=130)
                                  ####################label5##########################
                                  lb5=Label(window3,text="3:25 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=291,y=220)
                                  ####################label6##########################
                                  lb6=Label(window3,text="3:00 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=6,y=220)
                          elif(hourse==4 and (minute<=30 and am=='PM')): 
                              z=30
                              while(z<=250):
                                  f4=Frame(window3,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                   ####################label2##########################
                                  lb2=Label(window3,text="12:50 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=281,y=60)
                                  ####################label3##########################
                                  lb3=Label(window3,text="12:25 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=7,y=60)
                                  ####################label4##########################
                                  lb4=Label(window3,text="2:10 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb4.place(x=281,y=130)
                                  ####################label5##########################
                                  lb5=Label(window3,text="1:38 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb5.place(x=6,y=130)
                                  ####################label5##########################
                                  lb5=Label(window3,text="3:25 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=291,y=220)
                                  ####################label6##########################
                                  lb6=Label(window3,text="3:00 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=6,y=220)
                          elif(hourse==4 and (minute<=59 and am=='PM')): 
                              z=30
                              while(z<=270):
                                  f4=Frame(window3,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                   ####################label2##########################
                                  lb2=Label(window3,text="12:50 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=281,y=60)
                                  ####################label3##########################
                                  lb3=Label(window3,text="12:25 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=7,y=60)
                                  ####################label4##########################
                                  lb4=Label(window3,text="2:10 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb4.place(x=281,y=130)
                                  ####################label5##########################
                                  lb5=Label(window3,text="1:38 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb5.place(x=6,y=130)
                                  ####################label5##########################
                                  lb5=Label(window3,text="3:25 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=291,y=220)
                                  ####################label6##########################
                                  lb6=Label(window3,text="3:00 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=6,y=220)
                                  ####################label5##########################
                                  lb5=Label(window3,text="4:57 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=291,y=300)
                                  ####################label6##########################
                                  lb6=Label(window3,text="4:35 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=6,y=300)
                          elif(hourse==5 and (minute<=59 and am=='PM')): 
                              z=30
                              while(z<=300):
                                  f4=Frame(window3,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                   ####################label2##########################
                                  lb2=Label(window3,text="12:50 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=281,y=60)
                                  ####################label3##########################
                                  lb3=Label(window3,text="12:25 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=7,y=60)
                                  ####################label4##########################
                                  lb4=Label(window3,text="2:10 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb4.place(x=281,y=130)
                                  ####################label5##########################
                                  lb5=Label(window3,text="1:38 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb5.place(x=6,y=130)
                                  ####################label5##########################
                                  lb5=Label(window3,text="3:25 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=291,y=220)
                                  ####################label6##########################
                                  lb6=Label(window3,text="3:00 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=6,y=220)
                                  ####################label5##########################
                                  lb5=Label(window3,text="4:57 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=291,y=300)
                                  ####################label6##########################
                                  lb6=Label(window3,text="4:35 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=6,y=300)
                          elif(hourse==6 and (minute<=20 and am=='PM')): 
                              z=30
                              while(z<=330):
                                  f4=Frame(window3,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                   ####################label2##########################
                                  lb2=Label(window3,text="12:50 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=281,y=60)
                                  ####################label3##########################
                                  lb3=Label(window3,text="12:25 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=7,y=60)
                                  ####################label4##########################
                                  lb4=Label(window3,text="2:10 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb4.place(x=281,y=130)
                                  ####################label5##########################
                                  lb5=Label(window3,text="1:38 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb5.place(x=6,y=130)
                                  ####################label5##########################
                                  lb5=Label(window3,text="3:25 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=291,y=220)
                                  ####################label6##########################
                                  lb6=Label(window3,text="3:00 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=6,y=220)
                                  ####################label5##########################
                                  lb5=Label(window3,text="4:57 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=291,y=300)
                                  ####################label6##########################
                                  lb6=Label(window3,text="4:35 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=6,y=300)
                          elif(hourse==6 and (minute>=20 and am=='PM')): 
                              z=30
                              while(z<=350):
                                  f4=Frame(window3,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                   ####################label2##########################
                                  lb2=Label(window3,text="12:50 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=281,y=60)
                                  ####################label3##########################
                                  lb3=Label(window3,text="12:25 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=7,y=60)
                                  ####################label4##########################
                                  lb4=Label(window3,text="2:10 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb4.place(x=281,y=130)
                                  ####################label5##########################
                                  lb5=Label(window3,text="1:38 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb5.place(x=6,y=130)
                                  ####################label5##########################
                                  lb5=Label(window3,text="3:25 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=291,y=220)
                                  ####################label6##########################
                                  lb6=Label(window3,text="3:00 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=6,y=220)
                                  ####################label5##########################
                                  lb5=Label(window3,text="4:57 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=291,y=300)
                                  ####################label6##########################
                                  lb6=Label(window3,text="4:35 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=6,y=300)
                                  ####################label7##########################
                                  lb7=Label(window3,text="6:15 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb7.place(x=291,y=380)
                                  ####################label8##########################
                                  lb8=Label(window3,text="6:03 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb8.place(x=6,y=380)
                          
                          elif(hourse==6 and (minute>=55 and am=='PM')): 
                              z=30
                              while(z<=430):
                                  f4=Frame(window3,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                   ####################label2##########################
                                  lb2=Label(window3,text="12:50 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=281,y=60)
                                  ####################label3##########################
                                  lb3=Label(window3,text="12:25 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=7,y=60)
                                  ####################label4##########################
                                  lb4=Label(window3,text="2:10 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb4.place(x=281,y=130)
                                  ####################label5##########################
                                  lb5=Label(window3,text="1:38 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb5.place(x=6,y=130)
                                  ####################label5##########################
                                  lb5=Label(window3,text="3:25 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=291,y=220)
                                  ####################label6##########################
                                  lb6=Label(window3,text="3:00 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=6,y=220)
                                  ####################label5##########################
                                  lb5=Label(window3,text="4:57 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=291,y=300)
                                  ####################label6##########################
                                  lb6=Label(window3,text="4:35 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=6,y=300)
                                  ####################label7##########################
                                  lb7=Label(window3,text="6:15 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb7.place(x=291,y=380)
                                  ####################label8##########################
                                  lb8=Label(window3,text="6:03 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb8.place(x=6,y=380)
                                  ####################label7##########################
                                  lb7=Label(window3,text="--",bg='white',fg='black',font=('sans serif',16))
                                  lb7.place(x=311,y=460)
                                  ####################label8##########################
                                  lb8=Label(window3,text="6:55 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb8.place(x=6,y=460)
                          elif(hourse==6 and (minute<=55 and am=='PM')): 
                              z=30
                              while(z<=400):
                                  f4=Frame(window3,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                   ####################label2##########################
                                  lb2=Label(window3,text="12:50 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=281,y=60)
                                  ####################label3##########################
                                  lb3=Label(window3,text="12:25 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=7,y=60)
                                  ####################label4##########################
                                  lb4=Label(window3,text="2:10 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb4.place(x=281,y=130)
                                  ####################label5##########################
                                  lb5=Label(window3,text="1:38 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb5.place(x=6,y=130)
                                  ####################label5##########################
                                  lb5=Label(window3,text="3:25 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=291,y=220)
                                  ####################label6##########################
                                  lb6=Label(window3,text="3:00 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=6,y=220)
                                  ####################label5##########################
                                  lb5=Label(window3,text="4:57 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=291,y=300)
                                  ####################label6##########################
                                  lb6=Label(window3,text="4:35 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=6,y=300)
                                  ####################label7##########################
                                  lb7=Label(window3,text="6:15 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb7.place(x=291,y=380)
                                  ####################label8##########################
                                  lb8=Label(window3,text="6:03 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb8.place(x=6,y=380)
                          elif(hourse==6 and (minute<=55 and am=='PM')): 
                              z=30
                              while(z<=400):
                                  f4=Frame(window3,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                   ####################label2##########################
                                  lb2=Label(window3,text="12:50 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=281,y=60)
                                  ####################label3##########################
                                  lb3=Label(window3,text="12:25 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=7,y=60)
                                  ####################label4##########################
                                  lb4=Label(window3,text="2:10 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb4.place(x=281,y=130)
                                  ####################label5##########################
                                  lb5=Label(window3,text="1:38 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb5.place(x=6,y=130)
                                  ####################label5##########################
                                  lb5=Label(window3,text="3:25 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=291,y=220)
                                  ####################label6##########################
                                  lb6=Label(window3,text="3:00 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=6,y=220)
                                  ####################label5##########################
                                  lb5=Label(window3,text="4:57 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=291,y=300)
                                  ####################label6##########################
                                  lb6=Label(window3,text="4:35 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=6,y=300)
                                  ####################label7##########################
                                  lb7=Label(window3,text="6:15 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb7.place(x=291,y=380)
                                  ####################label8##########################
                                  lb8=Label(window3,text="6:03 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb8.place(x=6,y=380)
                          elif(hourse==6 and (minute<=59 and am=='PM')): 
                              z=30
                              while(z<=430):
                                  f4=Frame(window3,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                   ####################label2##########################
                                  lb2=Label(window3,text="12:50 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=281,y=60)
                                  ####################label3##########################
                                  lb3=Label(window3,text="12:25 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=7,y=60)
                                  ####################label4##########################
                                  lb4=Label(window3,text="2:10 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb4.place(x=281,y=130)
                                  ####################label5##########################
                                  lb5=Label(window3,text="1:38 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb5.place(x=6,y=130)
                                  ####################label5##########################
                                  lb5=Label(window3,text="3:25 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=291,y=220)
                                  ####################label6##########################
                                  lb6=Label(window3,text="3:00 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=6,y=220)
                                  ####################label5##########################
                                  lb5=Label(window3,text="4:57 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=291,y=300)
                                  ####################label6##########################
                                  lb6=Label(window3,text="4:35 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=6,y=300)
                                  ####################label7##########################
                                  lb7=Label(window3,text="6:15 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb7.place(x=291,y=380)
                                  ####################label8##########################
                                  lb8=Label(window3,text="6:03 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb8.place(x=6,y=380)
                          elif(hourse==8 and (minute<=59 and am=='PM')): 
                              z=30
                              while(z<=450):
                                  f4=Frame(window3,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                   ####################label2##########################
                                  lb2=Label(window3,text="12:50 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=281,y=60)
                                  ####################label3##########################
                                  lb3=Label(window3,text="12:25 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=7,y=60)
                                  ####################label4##########################
                                  lb4=Label(window3,text="2:10 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb4.place(x=281,y=130)
                                  ####################label5##########################
                                  lb5=Label(window3,text="1:38 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb5.place(x=6,y=130)
                                  ####################label5##########################
                                  lb5=Label(window3,text="3:25 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=291,y=220)
                                  ####################label6##########################
                                  lb6=Label(window3,text="3:00 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=6,y=220)
                                  ####################label5##########################
                                  lb5=Label(window3,text="4:57 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=291,y=300)
                                  ####################label6##########################
                                  lb6=Label(window3,text="4:35 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=6,y=300)
                                  ####################label7##########################
                                  lb7=Label(window3,text="6:15 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb7.place(x=291,y=380)
                                  ####################label8##########################
                                  lb8=Label(window3,text="6:03 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb8.place(x=6,y=380)
                          elif(hourse==9 and (minute<=15 and am=='PM')): 
                              z=30
                              while(z<=500):
                                  f4=Frame(window3,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                   ####################label2##########################
                                  lb2=Label(window3,text="12:50 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=281,y=60)
                                  ####################label3##########################
                                  lb3=Label(window3,text="12:25 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=7,y=60)
                                  ####################label4##########################
                                  lb4=Label(window3,text="2:10 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb4.place(x=281,y=130)
                                  ####################label5##########################
                                  lb5=Label(window3,text="1:38 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb5.place(x=6,y=130)
                                  ####################label5##########################
                                  lb5=Label(window3,text="3:25 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=291,y=220)
                                  ####################label6##########################
                                  lb6=Label(window3,text="3:00 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=6,y=220)
                                  ####################label5##########################
                                  lb5=Label(window3,text="4:57 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=291,y=300)
                                  ####################label6##########################
                                  lb6=Label(window3,text="4:35 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=6,y=300)
                                  ####################label7##########################
                                  lb7=Label(window3,text="6:15 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb7.place(x=291,y=380)
                                  ####################label8##########################
                                  lb8=Label(window3,text="6:03 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb8.place(x=6,y=380)
                          elif(hourse==9 and (minute>=15 and am=='PM')): 
                              z=30
                              while(z<=550):
                                  f4=Frame(window3,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                   ####################label2##########################
                                  lb2=Label(window3,text="12:50 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=281,y=60)
                                  ####################label3##########################
                                  lb3=Label(window3,text="12:25 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=7,y=60)
                                  ####################label4##########################
                                  lb4=Label(window3,text="2:10 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb4.place(x=281,y=130)
                                  ####################label5##########################
                                  lb5=Label(window3,text="1:38 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb5.place(x=6,y=130)
                                  ####################label5##########################
                                  lb5=Label(window3,text="3:25 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=291,y=220)
                                  ####################label6##########################
                                  lb6=Label(window3,text="3:00 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=6,y=220)
                                  ####################label5##########################
                                  lb5=Label(window3,text="4:57 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=291,y=300)
                                  ####################label6##########################
                                  lb6=Label(window3,text="4:35 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=6,y=300)
                                  ####################label7##########################
                                  lb7=Label(window3,text="6:15 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb7.place(x=291,y=380)
                                  ####################label8##########################
                                  lb8=Label(window3,text="6:03 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb8.place(x=6,y=380)
                                  ####################label7##########################
                                  lb7=Label(window3,text="--",bg='white',fg='black',font=('sans serif',16))
                                  lb7.place(x=311,y=460)
                                  ####################label8##########################
                                  lb8=Label(window3,text="6:55 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb8.place(x=6,y=460)
                                   ####################label9##########################
                                  lb9=Label(window3,text="--",bg='white',fg='black',font=('sans serif',16))
                                  lb9.place(x=311,y=580)
                                  ####################label10##########################
                                  lb10=Label(window3,text="9:13 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb10.place(x=6,y=580)
                          elif(hourse==9 and (minute<=59 and am=='PM')): 
                              z=30
                              while(z<=610):
                                  f4=Frame(window3,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                   ####################label2##########################
                                  lb2=Label(window3,text="12:50 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=281,y=60)
                                  ####################label3##########################
                                  lb3=Label(window3,text="12:25 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=7,y=60)
                                  ####################label4##########################
                                  lb4=Label(window3,text="2:10 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb4.place(x=281,y=130)
                                  ####################label5##########################
                                  lb5=Label(window3,text="1:38 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb5.place(x=6,y=130)
                                  ####################label5##########################
                                  lb5=Label(window3,text="3:25 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=291,y=220)
                                  ####################label6##########################
                                  lb6=Label(window3,text="3:00 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=6,y=220)
                                  ####################label5##########################
                                  lb5=Label(window3,text="4:57 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=291,y=300)
                                  ####################label6##########################
                                  lb6=Label(window3,text="4:35 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=6,y=300)
                                  ####################label7##########################
                                  lb7=Label(window3,text="6:15 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb7.place(x=291,y=380)
                                  ####################label8##########################
                                  lb8=Label(window3,text="6:03 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb8.place(x=6,y=380)
                                  ####################label7##########################
                                  lb7=Label(window3,text="--",bg='white',fg='black',font=('sans serif',16))
                                  lb7.place(x=311,y=460)
                                  ####################label8##########################
                                  lb8=Label(window3,text="6:55 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb8.place(x=6,y=460)
                                   ####################label9##########################
                                  lb9=Label(window3,text="--",bg='white',fg='black',font=('sans serif',16))
                                  lb9.place(x=311,y=580)
                                  ####################label10##########################
                                  lb10=Label(window3,text="9:13 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb10.place(x=6,y=580)
                                  lb11=Label(window3,text="--",bg='white',fg='black',font=('sans serif',16))
                                  lb11.place(x=311,y=640)
                                  ####################label12##########################
                                  lb12=Label(window3,text="9:50 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb12.place(x=6,y=640)
                      elif(hourse<=12 and (minute<=59 and am=='AM')):
                          f4=Frame(window3,height="39",width="30")
                          f4.place(x=88,y=30)
                          img7=Label(f4,image=img6,bg='skyblue',width="26")
                          img7.place(x=0,y=0)
                          if(hourse<=7 and (minute<=59 and am=='AM')): 
                              z=30
                              while(z<=610):
                                  f4=Frame(window3,height="39",width="30")
                                  f4.place(x=88,y=z)
                                  img7=Label(f4,image=img6,bg='skyblue',width="26")
                                  img7.place(x=0,y=0)
                                  z=z+10
                                   ####################label2##########################
                                  lb2=Label(window3,text="12:50 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb2.place(x=281,y=60)
                                  ####################label3##########################
                                  lb3=Label(window3,text="12:25 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb3.place(x=7,y=60)
                                  ####################label4##########################
                                  lb4=Label(window3,text="2:10 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb4.place(x=281,y=130)
                                  ####################label5##########################
                                  lb5=Label(window3,text="1:38 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb5.place(x=6,y=130)
                                  ####################label5##########################
                                  lb5=Label(window3,text="3:25 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=291,y=220)
                                  ####################label6##########################
                                  lb6=Label(window3,text="3:00 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=6,y=220)
                                  ####################label5##########################
                                  lb5=Label(window3,text="4:57 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb5.place(x=291,y=300)
                                  ####################label6##########################
                                  lb6=Label(window3,text="4:35 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb6.place(x=6,y=300)
                                  ####################label7##########################
                                  lb7=Label(window3,text="6:15 PM",bg='white',fg='red',font=('sans serif',12))
                                  lb7.place(x=291,y=380)
                                  ####################label8##########################
                                  lb8=Label(window3,text="6:03 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb8.place(x=6,y=380)
                                  ####################label7##########################
                                  lb7=Label(window3,text="--",bg='white',fg='black',font=('sans serif',16))
                                  lb7.place(x=311,y=460)
                                  ####################label8##########################
                                  lb8=Label(window3,text="6:55 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb8.place(x=6,y=460)
                                   ####################label9##########################
                                  lb9=Label(window3,text="--",bg='white',fg='black',font=('sans serif',16))
                                  lb9.place(x=311,y=580)
                                  ####################label10##########################
                                  lb10=Label(window3,text="9:13 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb10.place(x=6,y=580)
                                  lb11=Label(window3,text="--",bg='white',fg='black',font=('sans serif',16))
                                  lb11.place(x=311,y=640)
                                  ####################label12##########################
                                  lb12=Label(window3,text="9:50 PM",bg='white',fg='green',font=('sans serif',12))
                                  lb12.place(x=6,y=640)                                  
                  ########################bt12 for refresh to  prayagraj juction to new delhi ####################
                  bt12=Button(window3,text="Refresh",fg="blue",bg="white",font=('sans serif',12),command=refresh)
                  bt12.place(x=230,y=505)  
              lb6=Label(f1,text="   PRYJ - Prayagraj   ->   ANVT  -   Anand Vihar \n          Juction                            Terminal",bd=1,relief=RIDGE,font=('Sans-serif',13),fg='white',bg='Dodger blue')
              lb6.place(x=1,y=465)
    
              #############################bt11 for Express name###########################
              bt11=Button(f1,text="        12:25 PM -> 12:30 PM   \n\nNorth East Express                             \n",font=('sans serif',15),bg="white",command=nend)
              bt11.place(x=1,y=508)
              #############################lb12 for train number################################
              lb12=Label(bt11,text='12505',bg="Dodger blue",font=('sans serif ',14),fg="white")
              lb12.place(x=0,y=5)
              ################################lb13 for runs daily#################################
              lb13=Label(bt11,text="Runs Daily",font=("sans serif",14),fg="Dodger blue",bg="white")
              lb13.place(x=249,y=66)         
curdate=dt.date.today()
print(curdate)
hourse=time.strftime("%I")
minute=time.strftime("%M")
am=time.strftime("%p")
print(am)
print(hourse,minute)
hourse=int(hourse)
minute=int(minute)
###################frame1####################
f1=Frame(win,height="660",width="380",bd=10,relief=RIDGE)
f1.place(x=670,y=115)
###################frame3##########################
f3=Frame(f1,height="0",width="0")
f3.place(x=0,y=0)
###################img4 global variable for prayagraj juction to delhi on window#####################
img4=PhotoImage(file="C:\\Users\\Asus\\Desktop\\Doc2.png")
img5=Label(f3,image=img4)
img5.place(x=0,y=0)
#############img6 global variable for prayagraj juction to delhi on window ############################
img6=PhotoImage(file="C:\\Users\\Asus\\Desktop\\logo.png")
img7=Label(f3,image=img6)
img7.place(x=1,y=1)
############img8 global variable for prayagraj juction to delhi on window1#############################
img8=PhotoImage(file="C:\\Users\\Asus\\Desktop\\magadh update.png")
img9=Label(f3,image=img8)
img9.place(x=1,y=1)
############img10 global variable for prayagraj juction to delhi on window2#############################
img10=PhotoImage(file="C:\\Users\\Asus\\Desktop\\swatantrana senani express.png")
img11=Label(f3,image=img10)
img11.place(x=1,y=1)
############img12 global variable for prayagraj juction to delhi on window3#############################
img12=PhotoImage(file="C:\\Users\\Asus\\Desktop\\north east express.png")
img13=Label(f3,image=img12)
img13.place(x=1,y=1)
############img14 global variable for prayagraj juction to delhi on window3#############################
img14=PhotoImage(file="C:\\Users\\Asus\\Desktop\\update.png")
img15=Label(f1,image=img14)
img15.place(x=80,y=250)
########################FRAME2###############################
f2=Frame(win,height="120",width="1528",bd=10,relief=RIDGE)
f2.place(x=1,y=1)
#############label1#######################
lb1=Label(f2,text="Where Is My Train",font=('Imprint MT Shadow',60),fg="green")
lb1.place(x=410,y=1)
#############image1#######################
img=PhotoImage(file="C:\\Users\\Asus\\Desktop\\Metro-15.png")
img1=Label(win,image=img,bd=10,relief=RIDGE)
img1.place(x=1,y=115)
#############image2#######################
img2=PhotoImage(file="C:\\Users\\Asus\\Desktop\\boys.png")
img3=Label(win,image=img2,bd=10,relief=RIDGE)
img3.place(x=1050,y=380)
#############label2#######################
lb2=Label(win,text="From Station",font=(20),bg="white")
lb2.place(x=1110,y=420)
sf1=Frame(win,height="255",width="480",bg="Dodger blue",bd=10,relief=RIDGE)
sf1.place(x=1050,y=121)
slb1=Label(sf1,text="Search Train Number",font=(20),bg="Dodger blue",fg='white')
slb1.place(x=30,y=5)
######################se1#############################
se1=Entry(sf1,font=(10),fg="blue",border=7)
se1.place(x=30,y=40)
sb1=Button(sf1,text="Search",bg="green",fg="white",font=('sans-serif',12),border=7,command=findtrain)
sb1.place(x=275,y=38)
#############entry1#######################
e1=Entry(win,font=(10),fg="blue",border=7)
e1.place(x=1110,y=450)
#############label3#######################
lb3=Label(win,text="To Station",font=(20),bg="white")
lb3.place(x=1110,y=490)
#############entry2#################
e2=Entry(win,font=(10),fg='blue',border=7)
e2.place(x=1110,y=520)
###############button1################
bt1=Button(win,text="    Find trains     ",font=('Arial Rounded MT Bold',14),bg="green",fg="white",border=7,command=findtrain)
bt1.place(x=1140,y=580)


